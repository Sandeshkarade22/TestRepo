﻿using System;
using System.Collections.Generic;
using System.Text;
using Firefly.Box;
using ENV;
using ENV.Web;
using ENV.Data;

namespace WebDemo.ViewModels
{
    class TWBookingViewModel : ViewModel
    {
        Northwind.Models.TicketWindowBooking ticketWindowBooking = new Northwind.Models.TicketWindowBooking();
        public TWBookingViewModel()
        {
            From = ticketWindowBooking;
            //Where.Add(ticketWindowBooking.bookingId.IsEqualTo(21253482));
            AllowDelete = false;
            AllowInsert = false;
            AllowUpdate = false;
        }
        protected override void OnSavingRow()
        {
            ModelState.Exists(ticketWindowBooking.bookingId, new Northwind.Models.TicketWindowBooking().bookingId, "Booking id not found");
        }
    }
}
