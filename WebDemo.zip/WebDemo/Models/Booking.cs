﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebDemo.Models
{
    public class Booking
    {
        public int Account_id { get; set; }
        public string Account_Code { get; set; }// Account_Abbreviation
        public string Amadeus_PNR_No_Alpha { get; set; }
        public decimal Amount_Received { get; set; }
        public bool Archived_Yes_No { get; set; }
        public string Booked_by { get; set; }
        public string Booker { get; set; }
        public DateTime? Booking_Expiry_Date_Retail { get; set; }
        public int Booking_id { get; set; }
        public string Booking_Status { get; set; }
        public int Booking_Type_1_2_3 { get; set; }//  { get; set; } //smallint
        public int Booking_Type_ISN { get; set; }
        public string Branch_id { get; set; }
        public decimal Comm_BSP { get; set; }
        public decimal Comm_Car_Hire { get; set; }
        public decimal Comm_Flight_Consol { get; set; }
        public decimal Comm_Hotel { get; set; }
        public decimal Comm_Insurance { get; set; }
        public decimal Comm_Misc { get; set; }
        public decimal Comm_Package { get; set; }
        public decimal Comm_Rail { get; set; }
        public string Cost_Centre_Code { get; set; }
        public string Cost_Centre_Code_2 { get; set; }
        public string Country_Code { get; set; }
        public DateTime? Created_on_NU { get; set; }
        public string Currency_Code1 { get; set; }
        public DateTime? Date_Amended { get; set; }
        public DateTime? Date_Balance_Due { get; set; }
        public DateTime? Date_Created { get; set; }
        public string Depar_Flg { get; set; }
        public string Department_Group { get; set; }
        public DateTime? Departure_Date { get; set; }
        public bool diary_Entries_Exist { get; set; }
        public string Fare_Type_Code { get; set; }
        public bool Forced_fully_paid { get; set; }
        public string Future_Use_10 { get; set; }
        public decimal Future_Use101 { get; set; }
        public DateTime? Future_Use102 { get; set; }
        public DateTime? Future_Use103 { get; set; }
        public DateTime? Future_Use104 { get; set; }
        public int Future_Use81 { get; set; }
        public int Future_Use82 { get; set; }
        public int Future_Use83 { get; set; }
        public string Future_Use87 { get; set; }
        public int Galileo_Key { get; set; }
        public string Galileo_Sequence { get; set; }
        public string Health_Check { get; set; }
        public decimal How_did_you_Heard_of_us_ISN { get; set; }
        public int IATA_No { get; set; }//smallint
        public bool Intrim_Payment_4_Rec_Retai { get; set; }
        public int Invoice_Comment { get; set; }
        public DateTime? Invoice_Created { get; set; }
        public DateTime? Invoice_printed { get; set; }
        public bool Is_Credit { get; set; }
        public bool Is_Invoiced { get; set; }
        public bool Is_Receipt { get; set; }
        public bool Is_Refund { get; set; }
        public DateTime? Last_Statement { get; set; }
        public int Line_No { get; set; } //smallint
        public bool Logical_Group_Invoice { get; set; }
        public string major_class { get; set; }
        public int No_Inv_Printed { get; set; } //smallint
        public int No_of_BR { get; set; } //smallint
        public int No_of_BSP_Flight { get; set; } //smallint
        public int No_of_Car_Hire { get; set; } //smallint
        public int No_of_Flight { get; set; } //smallint
        public int No_of_Hotels { get; set; } //smallint
        public int No_of_Insurance { get; set; } //smallint
        public int No_of_Misc { get; set; } //smallint
        public int No_of_Packages { get; set; } //smallint
        public int No_of_Pax { get; set; }
        public bool Notepad_Enties_Exist { get; set; }
        public byte[] Notes { get; set; }// varbinary
        public DateTime? NU_Confirmed_Date { get; set; }
        public string Origin_Destination { get; set; }
        public string Original_Account { get; set; }
        public bool Originate_From_Web_Booking { get; set; }
        public int Passenger_Id { get; set; }
        public string Passport_Check { get; set; }
        public string PCC { get; set; }
        public string PCC_Booker { get; set; }
        public string PCC_Ticketer { get; set; }
        public string Project_Code { get; set; }
        public string Psedue_City_of_Agency_Booking { get; set; }
        public string Pseudo_City_Agency_Issue_Ticke { get; set; }
        public string Purchase_Order_No { get; set; }
        public bool Put_Retail_Pax_Add_on_Receipt { get; set; }
        public decimal Receipt_Paid { get; set; }
        public string Reference_1 { get; set; }
        public string Reference_10 { get; set; }
        public string Reference_11 { get; set; }
        public string Reference_12 { get; set; }
        public string Reference_13 { get; set; }
        public string Reference_14 { get; set; }
        public string Reference_15 { get; set; }
        public string Reference_2 { get; set; }
        public string Reference_3 { get; set; }
        public string Reference_4 { get; set; }
        public string Reference_5 { get; set; }
        public string Reference_6 { get; set; }
        public string Reference_7 { get; set; }
        public string Reference_8 { get; set; }
        public string Reference_9 { get; set; }
        public decimal Reference_M1 { get; set; }
        public decimal Reference_M10 { get; set; }
        public decimal Reference_M11 { get; set; }
        public decimal Reference_M12 { get; set; }
        public decimal Reference_M13 { get; set; }
        public decimal Reference_M14 { get; set; }
        public decimal Reference_M15 { get; set; }
        public decimal Reference_M16 { get; set; }
        public decimal Reference_M17 { get; set; }
        public decimal Reference_M18 { get; set; }
        public decimal Reference_M19 { get; set; }
        public decimal Reference_M2 { get; set; }
        public decimal Reference_M20 { get; set; }
        public decimal Reference_M3 { get; set; }
        public decimal Reference_M4 { get; set; }
        public decimal Reference_M5 { get; set; }
        public decimal Reference_M6 { get; set; }
        public decimal Reference_M7 { get; set; }
        public decimal Reference_M8 { get; set; }
        public decimal Reference_M9 { get; set; }
        public string Retail_Major_Destination { get; set; }
        public DateTime? Return_Date { get; set; }
        public decimal Sale_Total_Due_to_Supplier { get; set; }
        public string sales_agent { get; set; }
        public bool Supress_Diary_Entry { get; set; }
        public string Taxi_Yes_No { get; set; }
        public string Ticketer { get; set; }
        public decimal Total_Booking { get; set; }
        public decimal Total_Cost_BR { get; set; }
        public decimal Total_Cost_BSP_Flight { get; set; }
        public decimal Total_Cost_Car_Hire { get; set; }
        public decimal Total_Cost_Flight { get; set; }
        public decimal Total_Cost_Hotels { get; set; }
        public decimal Total_Cost_Insurance { get; set; }
        public decimal Total_Cost_Misc { get; set; }
        public decimal Total_Cost_Package { get; set; }
        public decimal Total_Currency_Comm_BSP { get; set; }
        public decimal Total_Currency_Comm_Car_Hire { get; set; }
        public decimal Total_Currency_Comm_Flight { get; set; }
        public decimal Total_Currency_Comm_Hotel { get; set; }
        public decimal Total_Currency_Comm_Insurance { get; set; }
        public decimal Total_Currency_Comm_Misc { get; set; }
        public decimal Total_Currency_Comm_Package { get; set; }
        public decimal Total_Currency_Comm_Rail { get; set; }
        public decimal Total_Currency_Cost_BSP { get; set; }
        public decimal Total_Currency_Cost_Car_Hire { get; set; }
        public decimal Total_Currency_Cost_Flight { get; set; }
        public decimal Total_Currency_Cost_Hotel { get; set; }
        public decimal Total_Currency_Cost_Insurance { get; set; }
        public decimal Total_Currency_Cost_Misc { get; set; }
        public decimal Total_Currency_Cost_Package { get; set; }
        public decimal Total_Currency_Cost_Rail { get; set; }
        public string Transaction_Fee_Type { get; set; }
        public string Travel_Policy_Override { get; set; }
        public decimal TW_Ref1 { get; set; }
        public decimal TW_Ref2 { get; set; }
        public decimal TW_Ref3 { get; set; }
        public string User_Amended { get; set; }
        public string User_Created { get; set; }
        public decimal Value_in_Currency_1 { get; set; }
        public string Visa_Check { get; set; }
        public List<Passenger> Passenger_List = new List<Passenger>();
        public List<BSPTravel> BSP_Travel_List = new List<BSPTravel>();
        public List<BSPDetails> BSP_Detail_List = new List<BSPDetails>();
        public List<Invoice> Invoice_List = new List<Invoice>();
        public List<NewCost> Costing_List = new List<NewCost>();
    }
}