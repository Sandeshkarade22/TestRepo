﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebDemo.Models
{
    public class Passenger
    {
        public int Account_Id { get; set; }
        public string Address_line_1 { get; set; }
        public string Address_line_2 { get; set; }
        public string Address_line_3 { get; set; }
        public string Address_line_4 { get; set; }
        public int Booking_Id { get; set; }
        public string Branch_Id { get; set; }
        public DateTime Date_Amended { get; set; }
        public DateTime Date_Created { get; set; }
        public string Department_Id { get; set; }
        public string Email { get; set; }
        public string Fax_No { get; set; }
        public string Future_Use29 { get; set; }
        public string Future_Use30 { get; set; }
        public bool Future_Use31 { get; set; }
        public bool Future_Use32 { get; set; }
        public decimal Future_Use33 { get; set; }
        public string Initials { get; set; }
        public string Job_Title { get; set; }
        public short Line_Number { get; set; }
        public bool Main_Contact_Important { get; set; }
        public bool? Main_Passenger { get; set; }
        public string Meal_Request { get; set; }
        public string Medical_Request { get; set; }
        public string Mobil { get; set; }
        public string Passenger_First_Name { get; set; }
        public int Passenger_Id { get; set; }
        public byte[] Passenger_Information { get; set; }
        public DateTime Passport_Expriry_Date { get; set; }
        public byte[] Passport_No { get; set; }
        public string Passenger_Surname { get; set; }
        public string Passport_Number { get; set; }
        public string Passport_Origin_1 { get; set; }
        public string Passport_Origin_2 { get; set; }
        public string Post_Code { get; set; }
        public string Profile_Name { get; set; }
        public string Telephone_No_1 { get; set; }
        public string Telephone_No_2 { get; set; }
        public string Title { get; set; }
        public string User_Amended { get; set; }
        public string User_Created { get; set; }
    }
}