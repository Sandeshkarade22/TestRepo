﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebDemo.Models
{
    public class BSPTravel
    {
        public string ADM_ACM_MAN_None { get; set; }
        public DateTime? AIR_Creation_Date { get; set; }
        public string Airline_Ticket { get; set; }
        public bool Allows_Change_Costing { get; set; }
        public bool Allows_Change_Refund { get; set; }
        public string Amadeus_PNR_No_Alpha { get; set; }
        public string Area_Code { get; set; }
        public int Booking_id { get; set; }
        public string Booking_reference_no { get; set; }
        public string Branch_id { get; set; }
        public bool BSP_Air_CRS_t_NonCRS_f { get; set; }
        public string BSP_Air_Trans_Fee { get; set; }
        public short BSP_Page_No { get; set; }
        public string BSP_RAS { get; set; }
        public decimal? BSP_Ref1 { get; set; }
        public decimal? BSP_Ref2 { get; set; }
        public decimal? BSP_Ref3 { get; set; }
        public bool CB_Flag { get; set; }
        public decimal City_Airport_ISN { get; set; }
        public string Class_of_Travel { get; set; }
        public decimal CN_Amount { get; set; }
        public bool CN_for_Ln { get; set; }
        public decimal Company_Policy { get; set; }
        public decimal? Company_Policy_AsEntered { get; set; }
        public string Corporate_ID { get; set; }
        public decimal Cost_Per_Person { get; set; }
        public decimal Cost_Total_IPT { get; set; }
        public decimal Cost_Total_Tax { get; set; }
        public decimal Cost_Total_VAT { get; set; }
        public string Country_Code { get; set; }
        public bool Create_Chque_Rec { get; set; }
        public string CRS_Command { get; set; }
        public decimal? Currency_Amount { get; set; }
        public DateTime Date_Amended { get; set; }
        public DateTime Date_Created { get; set; }
        public DateTime Date_Depart { get; set; }
        public string Deal_Number { get; set; }
        public decimal Discount { get; set; }
        public string EMD_RFIC_Code { get; set; }
        public string EMD_Type { get; set; }
        public decimal Fare_Offered { get; set; }
        public decimal? Fare_Offered_AsEntered { get; set; }
        public DateTime? FX_PL { get; set; }
        public DateTime? FX_SL { get; set; }
        public int Galileo_Key { get; set; }
        public string Galileo_Sequence { get; set; }
        public string Itinerary_TEXT { get; set; }
        public bool Is_Ticket_Exist { get; set; }
        public DateTime? Last_PNR_Changed { get; set; }
        public string Link_to_Misc_Currency { get; set; }
        public decimal? Link_to_Misc_Cost { get; set; }
        public bool? Link_to_Misc_Done_Update { get; set; }
        public int? Link_to_Misc_Page { get; set; }
        public string Link_to_Misc_Reference { get; set; }
        public int? Link_to_Misc_Supplier { get; set; }
        public decimal? MIR_ISN { get; set; }
        public string MIR_Type { get; set; }
        public short No_of_pax { get; set; }
        public decimal? ORFEE { get; set; }
        public string Original_Inv { get; set; }
        public string Originated_CRS { get; set; }
        public decimal Pay_Total_Paid_Account { get; set; }
        public decimal Pay_Total_VAT_Amt_CC { get; set; }
        public DateTime? PNR_Date_Created { get; set; }
        public decimal Published_Fare { get; set; }
        public decimal? Publish_Fare_AsEntered { get; set; }
        public string RB_Inv_CN { get; set; }
        public string Reason_Code { get; set; }
        public string Reason_Code2 { get; set; }
        public bool Refund_Only_Retail { get; set; }
        public string Remark_Comment_50 { get; set; }
        public DateTime Return_Date { get; set; }
        public bool? Split_Ticket_Logic { get; set; }
        public decimal Sup_Total_Commission { get; set; }
        public decimal Sup_Total_Commission_Amount { get; set; }
        public decimal Sup_Total_Due_to_Supplier { get; set; }
        public decimal Sup_Total_VAT_Amount { get; set; }
        public string Supplier_Curr { get; set; }
        public decimal Tax_Per_Person { get; set; }
        public string Ticket_Number_Alpha_13 { get; set; }
        public decimal Total_Cost { get; set; }
        public decimal Total_Paid { get; set; }
        public decimal Transaction_Fee_Value { get; set; }
        public bool Unprocessed_Refund { get; set; }
        public string User_Created { get; set; }
        public string User_Last_Amend { get; set; }
        public string Vendor_Locator_Mainly_WorldSpa { get; set; }
        public bool Went_into_Costing { get; set; }
    }
}