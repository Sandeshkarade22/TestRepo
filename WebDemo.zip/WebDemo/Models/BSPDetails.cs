﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebDemo.Models
{
    public class BSPDetails
    {
        public string Airline_Name { get; set; }
        public string Arrival_Date { get; set; }
        public string Arrive_Terminal { get; set; }
        public string Arrive_Time { get; set; }
        public string Arrive_To { get; set; }
        public string Baggage_Restriction { get; set; }
        public int Booking_id { get; set; }
        public string Branch_id { get; set; }
        public short BSP_Page_No { get; set; }
        public string Class_of_Travel { get; set; }
        public decimal Cost_Per_Sector { get; set; }
        public DateTime Date_Created { get; set; }
        public DateTime Date_Last_Amended { get; set; }
        public DateTime Depart_Date { get; set; }
        public string Depart_From { get; set; }
        public string Depart_Terminal_From_WS_NU { get; set; }
        public string Depart_Time { get; set; }
        public string Fare_Basis { get; set; }
        public decimal Fee_per_Sector { get; set; }
        public string Flight_Number { get; set; }
        public int Future_Use28 { get; set; }
        public bool Future_Use16 { get; set; }
        public bool Future_Use17 { get; set; }
        public string Itinery_DepartTerminal_Details { get; set; }
        public string Itinery_Free_Format { get; set; }
        public bool Load_from_PNR { get; set; }
        public short Line_No { get; set; }
        public int Miles { get; set; }
        public string Name { get; set; }
        public string Plan_Type { get; set; }
        public string Status { get; set; }
        public bool Surface_Yes_No { get; set; }
        public string TOUR_Code { get; set; }
        public string TOUR_Code_Pax { get; set; }
        public string Time_Format { get; set; }
        public string User_Created { get; set; }
        public string User_Last_Amended { get; set; }
        public string Vendor_Locator { get; set; }
        public string X_Connection_O_Destination { get; set; }
    }
}